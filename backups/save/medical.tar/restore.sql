--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.11
-- Dumped by pg_dump version 14.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE medical;
--
-- Name: medical; Type: DATABASE; Schema: -; Owner: doadmin
--

CREATE DATABASE medical WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.UTF-8';


ALTER DATABASE medical OWNER TO doadmin;

\connect medical

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Car; Type: TABLE; Schema: public; Owner: medical
--

CREATE TABLE public."Car" (
    id integer NOT NULL,
    plate text NOT NULL
);


ALTER TABLE public."Car" OWNER TO medical;

--
-- Name: Car_id_seq; Type: SEQUENCE; Schema: public; Owner: medical
--

CREATE SEQUENCE public."Car_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Car_id_seq" OWNER TO medical;

--
-- Name: Car_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: medical
--

ALTER SEQUENCE public."Car_id_seq" OWNED BY public."Car".id;


--
-- Name: Delivery; Type: TABLE; Schema: public; Owner: medical
--

CREATE TABLE public."Delivery" (
    id integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "deliveredAt" timestamp(3) without time zone,
    "fromId" integer NOT NULL,
    "toId" integer NOT NULL,
    "driverId" integer NOT NULL,
    "carId" integer NOT NULL
);


ALTER TABLE public."Delivery" OWNER TO medical;

--
-- Name: Delivery_id_seq; Type: SEQUENCE; Schema: public; Owner: medical
--

CREATE SEQUENCE public."Delivery_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Delivery_id_seq" OWNER TO medical;

--
-- Name: Delivery_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: medical
--

ALTER SEQUENCE public."Delivery_id_seq" OWNED BY public."Delivery".id;


--
-- Name: Driver; Type: TABLE; Schema: public; Owner: medical
--

CREATE TABLE public."Driver" (
    id integer NOT NULL,
    name text NOT NULL,
    "userId" integer NOT NULL
);


ALTER TABLE public."Driver" OWNER TO medical;

--
-- Name: Driver_id_seq; Type: SEQUENCE; Schema: public; Owner: medical
--

CREATE SEQUENCE public."Driver_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Driver_id_seq" OWNER TO medical;

--
-- Name: Driver_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: medical
--

ALTER SEQUENCE public."Driver_id_seq" OWNED BY public."Driver".id;


--
-- Name: Parcel; Type: TABLE; Schema: public; Owner: medical
--

CREATE TABLE public."Parcel" (
    id integer NOT NULL,
    barcode_data text NOT NULL,
    barcode_type text NOT NULL
);


ALTER TABLE public."Parcel" OWNER TO medical;

--
-- Name: Parcel_id_seq; Type: SEQUENCE; Schema: public; Owner: medical
--

CREATE SEQUENCE public."Parcel_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Parcel_id_seq" OWNER TO medical;

--
-- Name: Parcel_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: medical
--

ALTER SEQUENCE public."Parcel_id_seq" OWNED BY public."Parcel".id;


--
-- Name: Place; Type: TABLE; Schema: public; Owner: medical
--

CREATE TABLE public."Place" (
    id integer NOT NULL,
    name text NOT NULL
);


ALTER TABLE public."Place" OWNER TO medical;

--
-- Name: Place_id_seq; Type: SEQUENCE; Schema: public; Owner: medical
--

CREATE SEQUENCE public."Place_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Place_id_seq" OWNER TO medical;

--
-- Name: Place_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: medical
--

ALTER SEQUENCE public."Place_id_seq" OWNED BY public."Place".id;


--
-- Name: Project; Type: TABLE; Schema: public; Owner: medical
--

CREATE TABLE public."Project" (
    id integer NOT NULL,
    name text NOT NULL
);


ALTER TABLE public."Project" OWNER TO medical;

--
-- Name: Project_id_seq; Type: SEQUENCE; Schema: public; Owner: medical
--

CREATE SEQUENCE public."Project_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Project_id_seq" OWNER TO medical;

--
-- Name: Project_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: medical
--

ALTER SEQUENCE public."Project_id_seq" OWNED BY public."Project".id;


--
-- Name: Receit; Type: TABLE; Schema: public; Owner: medical
--

CREATE TABLE public."Receit" (
    id text NOT NULL,
    name text NOT NULL,
    signature text NOT NULL,
    "deliveryId" integer NOT NULL
);


ALTER TABLE public."Receit" OWNER TO medical;

--
-- Name: User; Type: TABLE; Schema: public; Owner: medical
--

CREATE TABLE public."User" (
    id integer NOT NULL,
    email text NOT NULL,
    password text NOT NULL
);


ALTER TABLE public."User" OWNER TO medical;

--
-- Name: User_id_seq; Type: SEQUENCE; Schema: public; Owner: medical
--

CREATE SEQUENCE public."User_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."User_id_seq" OWNER TO medical;

--
-- Name: User_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: medical
--

ALTER SEQUENCE public."User_id_seq" OWNED BY public."User".id;


--
-- Name: _CarToProject; Type: TABLE; Schema: public; Owner: medical
--

CREATE TABLE public."_CarToProject" (
    "A" integer NOT NULL,
    "B" integer NOT NULL
);


ALTER TABLE public."_CarToProject" OWNER TO medical;

--
-- Name: _DeliveryToParcel; Type: TABLE; Schema: public; Owner: medical
--

CREATE TABLE public."_DeliveryToParcel" (
    "A" integer NOT NULL,
    "B" integer NOT NULL
);


ALTER TABLE public."_DeliveryToParcel" OWNER TO medical;

--
-- Name: _DriverToProject; Type: TABLE; Schema: public; Owner: medical
--

CREATE TABLE public."_DriverToProject" (
    "A" integer NOT NULL,
    "B" integer NOT NULL
);


ALTER TABLE public."_DriverToProject" OWNER TO medical;

--
-- Name: _PlaceToProject; Type: TABLE; Schema: public; Owner: medical
--

CREATE TABLE public."_PlaceToProject" (
    "A" integer NOT NULL,
    "B" integer NOT NULL
);


ALTER TABLE public."_PlaceToProject" OWNER TO medical;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: medical
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO medical;

--
-- Name: Car id; Type: DEFAULT; Schema: public; Owner: medical
--

ALTER TABLE ONLY public."Car" ALTER COLUMN id SET DEFAULT nextval('public."Car_id_seq"'::regclass);


--
-- Name: Delivery id; Type: DEFAULT; Schema: public; Owner: medical
--

ALTER TABLE ONLY public."Delivery" ALTER COLUMN id SET DEFAULT nextval('public."Delivery_id_seq"'::regclass);


--
-- Name: Driver id; Type: DEFAULT; Schema: public; Owner: medical
--

ALTER TABLE ONLY public."Driver" ALTER COLUMN id SET DEFAULT nextval('public."Driver_id_seq"'::regclass);


--
-- Name: Parcel id; Type: DEFAULT; Schema: public; Owner: medical
--

ALTER TABLE ONLY public."Parcel" ALTER COLUMN id SET DEFAULT nextval('public."Parcel_id_seq"'::regclass);


--
-- Name: Place id; Type: DEFAULT; Schema: public; Owner: medical
--

ALTER TABLE ONLY public."Place" ALTER COLUMN id SET DEFAULT nextval('public."Place_id_seq"'::regclass);


--
-- Name: Project id; Type: DEFAULT; Schema: public; Owner: medical
--

ALTER TABLE ONLY public."Project" ALTER COLUMN id SET DEFAULT nextval('public."Project_id_seq"'::regclass);


--
-- Name: User id; Type: DEFAULT; Schema: public; Owner: medical
--

ALTER TABLE ONLY public."User" ALTER COLUMN id SET DEFAULT nextval('public."User_id_seq"'::regclass);


--
-- Data for Name: Car; Type: TABLE DATA; Schema: public; Owner: medical
--

COPY public."Car" (id, plate) FROM stdin;
\.
COPY public."Car" (id, plate) FROM '$$PATH$$/4033.dat';

--
-- Data for Name: Delivery; Type: TABLE DATA; Schema: public; Owner: medical
--

COPY public."Delivery" (id, "createdAt", "deliveredAt", "fromId", "toId", "driverId", "carId") FROM stdin;
\.
COPY public."Delivery" (id, "createdAt", "deliveredAt", "fromId", "toId", "driverId", "carId") FROM '$$PATH$$/4031.dat';

--
-- Data for Name: Driver; Type: TABLE DATA; Schema: public; Owner: medical
--

COPY public."Driver" (id, name, "userId") FROM stdin;
\.
COPY public."Driver" (id, name, "userId") FROM '$$PATH$$/4037.dat';

--
-- Data for Name: Parcel; Type: TABLE DATA; Schema: public; Owner: medical
--

COPY public."Parcel" (id, barcode_data, barcode_type) FROM stdin;
\.
COPY public."Parcel" (id, barcode_data, barcode_type) FROM '$$PATH$$/4040.dat';

--
-- Data for Name: Place; Type: TABLE DATA; Schema: public; Owner: medical
--

COPY public."Place" (id, name) FROM stdin;
\.
COPY public."Place" (id, name) FROM '$$PATH$$/4035.dat';

--
-- Data for Name: Project; Type: TABLE DATA; Schema: public; Owner: medical
--

COPY public."Project" (id, name) FROM stdin;
\.
COPY public."Project" (id, name) FROM '$$PATH$$/4029.dat';

--
-- Data for Name: Receit; Type: TABLE DATA; Schema: public; Owner: medical
--

COPY public."Receit" (id, name, signature, "deliveryId") FROM stdin;
\.
COPY public."Receit" (id, name, signature, "deliveryId") FROM '$$PATH$$/4038.dat';

--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: medical
--

COPY public."User" (id, email, password) FROM stdin;
\.
COPY public."User" (id, email, password) FROM '$$PATH$$/4027.dat';

--
-- Data for Name: _CarToProject; Type: TABLE DATA; Schema: public; Owner: medical
--

COPY public."_CarToProject" ("A", "B") FROM stdin;
\.
COPY public."_CarToProject" ("A", "B") FROM '$$PATH$$/4042.dat';

--
-- Data for Name: _DeliveryToParcel; Type: TABLE DATA; Schema: public; Owner: medical
--

COPY public."_DeliveryToParcel" ("A", "B") FROM stdin;
\.
COPY public."_DeliveryToParcel" ("A", "B") FROM '$$PATH$$/4041.dat';

--
-- Data for Name: _DriverToProject; Type: TABLE DATA; Schema: public; Owner: medical
--

COPY public."_DriverToProject" ("A", "B") FROM stdin;
\.
COPY public."_DriverToProject" ("A", "B") FROM '$$PATH$$/4044.dat';

--
-- Data for Name: _PlaceToProject; Type: TABLE DATA; Schema: public; Owner: medical
--

COPY public."_PlaceToProject" ("A", "B") FROM stdin;
\.
COPY public."_PlaceToProject" ("A", "B") FROM '$$PATH$$/4043.dat';

--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: medical
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
\.
COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM '$$PATH$$/4025.dat';

--
-- Name: Car_id_seq; Type: SEQUENCE SET; Schema: public; Owner: medical
--

SELECT pg_catalog.setval('public."Car_id_seq"', 9, true);


--
-- Name: Delivery_id_seq; Type: SEQUENCE SET; Schema: public; Owner: medical
--

SELECT pg_catalog.setval('public."Delivery_id_seq"', 121, true);


--
-- Name: Driver_id_seq; Type: SEQUENCE SET; Schema: public; Owner: medical
--

SELECT pg_catalog.setval('public."Driver_id_seq"', 2, true);


--
-- Name: Parcel_id_seq; Type: SEQUENCE SET; Schema: public; Owner: medical
--

SELECT pg_catalog.setval('public."Parcel_id_seq"', 27, true);


--
-- Name: Place_id_seq; Type: SEQUENCE SET; Schema: public; Owner: medical
--

SELECT pg_catalog.setval('public."Place_id_seq"', 22, true);


--
-- Name: Project_id_seq; Type: SEQUENCE SET; Schema: public; Owner: medical
--

SELECT pg_catalog.setval('public."Project_id_seq"', 5, true);


--
-- Name: User_id_seq; Type: SEQUENCE SET; Schema: public; Owner: medical
--

SELECT pg_catalog.setval('public."User_id_seq"', 2, true);


--
-- Name: Car Car_pkey; Type: CONSTRAINT; Schema: public; Owner: medical
--

ALTER TABLE ONLY public."Car"
    ADD CONSTRAINT "Car_pkey" PRIMARY KEY (id);


--
-- Name: Delivery Delivery_pkey; Type: CONSTRAINT; Schema: public; Owner: medical
--

ALTER TABLE ONLY public."Delivery"
    ADD CONSTRAINT "Delivery_pkey" PRIMARY KEY (id);


--
-- Name: Driver Driver_pkey; Type: CONSTRAINT; Schema: public; Owner: medical
--

ALTER TABLE ONLY public."Driver"
    ADD CONSTRAINT "Driver_pkey" PRIMARY KEY (id);


--
-- Name: Parcel Parcel_pkey; Type: CONSTRAINT; Schema: public; Owner: medical
--

ALTER TABLE ONLY public."Parcel"
    ADD CONSTRAINT "Parcel_pkey" PRIMARY KEY (id);


--
-- Name: Place Place_pkey; Type: CONSTRAINT; Schema: public; Owner: medical
--

ALTER TABLE ONLY public."Place"
    ADD CONSTRAINT "Place_pkey" PRIMARY KEY (id);


--
-- Name: Project Project_pkey; Type: CONSTRAINT; Schema: public; Owner: medical
--

ALTER TABLE ONLY public."Project"
    ADD CONSTRAINT "Project_pkey" PRIMARY KEY (id);


--
-- Name: Receit Receit_pkey; Type: CONSTRAINT; Schema: public; Owner: medical
--

ALTER TABLE ONLY public."Receit"
    ADD CONSTRAINT "Receit_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: medical
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: medical
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: Car_plate_key; Type: INDEX; Schema: public; Owner: medical
--

CREATE UNIQUE INDEX "Car_plate_key" ON public."Car" USING btree (plate);


--
-- Name: Driver_userId_key; Type: INDEX; Schema: public; Owner: medical
--

CREATE UNIQUE INDEX "Driver_userId_key" ON public."Driver" USING btree ("userId");


--
-- Name: Parcel_barcode_data_barcode_type_key; Type: INDEX; Schema: public; Owner: medical
--

CREATE UNIQUE INDEX "Parcel_barcode_data_barcode_type_key" ON public."Parcel" USING btree (barcode_data, barcode_type);


--
-- Name: Receit_deliveryId_key; Type: INDEX; Schema: public; Owner: medical
--

CREATE UNIQUE INDEX "Receit_deliveryId_key" ON public."Receit" USING btree ("deliveryId");


--
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: medical
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- Name: _CarToProject_AB_unique; Type: INDEX; Schema: public; Owner: medical
--

CREATE UNIQUE INDEX "_CarToProject_AB_unique" ON public."_CarToProject" USING btree ("A", "B");


--
-- Name: _CarToProject_B_index; Type: INDEX; Schema: public; Owner: medical
--

CREATE INDEX "_CarToProject_B_index" ON public."_CarToProject" USING btree ("B");


--
-- Name: _DeliveryToParcel_AB_unique; Type: INDEX; Schema: public; Owner: medical
--

CREATE UNIQUE INDEX "_DeliveryToParcel_AB_unique" ON public."_DeliveryToParcel" USING btree ("A", "B");


--
-- Name: _DeliveryToParcel_B_index; Type: INDEX; Schema: public; Owner: medical
--

CREATE INDEX "_DeliveryToParcel_B_index" ON public."_DeliveryToParcel" USING btree ("B");


--
-- Name: _DriverToProject_AB_unique; Type: INDEX; Schema: public; Owner: medical
--

CREATE UNIQUE INDEX "_DriverToProject_AB_unique" ON public."_DriverToProject" USING btree ("A", "B");


--
-- Name: _DriverToProject_B_index; Type: INDEX; Schema: public; Owner: medical
--

CREATE INDEX "_DriverToProject_B_index" ON public."_DriverToProject" USING btree ("B");


--
-- Name: _PlaceToProject_AB_unique; Type: INDEX; Schema: public; Owner: medical
--

CREATE UNIQUE INDEX "_PlaceToProject_AB_unique" ON public."_PlaceToProject" USING btree ("A", "B");


--
-- Name: _PlaceToProject_B_index; Type: INDEX; Schema: public; Owner: medical
--

CREATE INDEX "_PlaceToProject_B_index" ON public."_PlaceToProject" USING btree ("B");


--
-- Name: Delivery Delivery_carId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: medical
--

ALTER TABLE ONLY public."Delivery"
    ADD CONSTRAINT "Delivery_carId_fkey" FOREIGN KEY ("carId") REFERENCES public."Car"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Delivery Delivery_driverId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: medical
--

ALTER TABLE ONLY public."Delivery"
    ADD CONSTRAINT "Delivery_driverId_fkey" FOREIGN KEY ("driverId") REFERENCES public."Driver"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Delivery Delivery_fromId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: medical
--

ALTER TABLE ONLY public."Delivery"
    ADD CONSTRAINT "Delivery_fromId_fkey" FOREIGN KEY ("fromId") REFERENCES public."Place"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Delivery Delivery_toId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: medical
--

ALTER TABLE ONLY public."Delivery"
    ADD CONSTRAINT "Delivery_toId_fkey" FOREIGN KEY ("toId") REFERENCES public."Place"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Driver Driver_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: medical
--

ALTER TABLE ONLY public."Driver"
    ADD CONSTRAINT "Driver_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Receit Receit_deliveryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: medical
--

ALTER TABLE ONLY public."Receit"
    ADD CONSTRAINT "Receit_deliveryId_fkey" FOREIGN KEY ("deliveryId") REFERENCES public."Delivery"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: _CarToProject _CarToProject_A_fkey; Type: FK CONSTRAINT; Schema: public; Owner: medical
--

ALTER TABLE ONLY public."_CarToProject"
    ADD CONSTRAINT "_CarToProject_A_fkey" FOREIGN KEY ("A") REFERENCES public."Car"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: _CarToProject _CarToProject_B_fkey; Type: FK CONSTRAINT; Schema: public; Owner: medical
--

ALTER TABLE ONLY public."_CarToProject"
    ADD CONSTRAINT "_CarToProject_B_fkey" FOREIGN KEY ("B") REFERENCES public."Project"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: _DeliveryToParcel _DeliveryToParcel_A_fkey; Type: FK CONSTRAINT; Schema: public; Owner: medical
--

ALTER TABLE ONLY public."_DeliveryToParcel"
    ADD CONSTRAINT "_DeliveryToParcel_A_fkey" FOREIGN KEY ("A") REFERENCES public."Delivery"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: _DeliveryToParcel _DeliveryToParcel_B_fkey; Type: FK CONSTRAINT; Schema: public; Owner: medical
--

ALTER TABLE ONLY public."_DeliveryToParcel"
    ADD CONSTRAINT "_DeliveryToParcel_B_fkey" FOREIGN KEY ("B") REFERENCES public."Parcel"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: _DriverToProject _DriverToProject_A_fkey; Type: FK CONSTRAINT; Schema: public; Owner: medical
--

ALTER TABLE ONLY public."_DriverToProject"
    ADD CONSTRAINT "_DriverToProject_A_fkey" FOREIGN KEY ("A") REFERENCES public."Driver"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: _DriverToProject _DriverToProject_B_fkey; Type: FK CONSTRAINT; Schema: public; Owner: medical
--

ALTER TABLE ONLY public."_DriverToProject"
    ADD CONSTRAINT "_DriverToProject_B_fkey" FOREIGN KEY ("B") REFERENCES public."Project"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: _PlaceToProject _PlaceToProject_A_fkey; Type: FK CONSTRAINT; Schema: public; Owner: medical
--

ALTER TABLE ONLY public."_PlaceToProject"
    ADD CONSTRAINT "_PlaceToProject_A_fkey" FOREIGN KEY ("A") REFERENCES public."Place"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: _PlaceToProject _PlaceToProject_B_fkey; Type: FK CONSTRAINT; Schema: public; Owner: medical
--

ALTER TABLE ONLY public."_PlaceToProject"
    ADD CONSTRAINT "_PlaceToProject_B_fkey" FOREIGN KEY ("B") REFERENCES public."Project"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

